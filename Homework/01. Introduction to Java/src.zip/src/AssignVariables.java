
public class AssignVariables {
    public static void main(String[] args) {
        boolean bool = false;
        String str = "Palo Alto, CA";
        short numberShort = 32767;
        int numberInt = 2_000_000_000;
        double numberDouble = 0.1234567891011;
        float numberFloat = 0.5f;
        long numberLong = 919827112351L;
        byte numberByte = 127;
        char ch = 'c';
        System.out.println("Boolean: " + bool);
        System.out.println("String: " + str);
        System.out.println("Short: " + numberShort);
        System.out.println("Int: " + numberInt);
        System.out.println("Double: " + numberDouble);
        System.out.println("Float: " + numberFloat);
        System.out.println("Long: " + numberLong);
        System.out.println("Byte: " + numberByte);
        System.out.println("Char: " + ch);
    }
}
