package oneLvShop;

import java.util.Date;

public interface Expirable {
	Date getExpirationDate();
}
