package oneLvShop;

public enum AgeRestriction {
	None,
	Teenager,
	Adult
}
