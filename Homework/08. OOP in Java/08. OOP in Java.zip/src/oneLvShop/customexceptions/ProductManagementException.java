package oneLvShop.customexceptions;

public class ProductManagementException extends Exception {
	public ProductManagementException(String message) {
		super(message);
	}
}
