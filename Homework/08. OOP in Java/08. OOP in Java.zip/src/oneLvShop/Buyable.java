package oneLvShop;

import java.math.BigDecimal;

public interface Buyable {
	BigDecimal getPrice();
}
