package Geometry.Interfaces;

public interface VolumeMeasurable {
    double getVolume();
}