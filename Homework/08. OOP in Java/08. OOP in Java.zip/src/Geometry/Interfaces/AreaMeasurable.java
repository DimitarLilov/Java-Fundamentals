package Geometry.Interfaces;

public interface AreaMeasurable {
    double getArea();
}